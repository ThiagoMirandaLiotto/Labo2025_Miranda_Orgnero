package algoritmos;

public class IngresoDatos {
    public static void main(String[] args) {
        //Declarar y dar valores a las variables
        int N = 32;
        double A = 54;
        char C = 'L';

        //Mostrar las variables
        System.out.println(N);
        System.out.println(A);
        System.out.println(C);

        //'N + A' - 'A - N' - 'Valor numerico de A'
        System.out.println(N + A);
        System.out.println(A - N);

        int intC = C;
        System.out.println(intC);



    }
}
