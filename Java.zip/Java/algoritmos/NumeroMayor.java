package algoritmos;

public class NumeroMayor {
    public static void main(String[] args) {
        int A = 67  ;
        int B = 65;

        if (A > B){
            System.out.println("A es la variable mayor");
        }else{
            System.out.println("B es la variable mayor");
        }

    }
}
